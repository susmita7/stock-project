let tl_1=gsap.timeline({defaults:{duration:1.1}});

tl_1.from('#text_left' , {opacity:0 , y:-100 , stagger:.4})