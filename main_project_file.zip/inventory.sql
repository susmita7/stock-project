-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2020 at 10:09 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_type`
--

CREATE TABLE `category_type` (
  `type_id` int(11) NOT NULL,
  `type_name` varchar(256) NOT NULL,
  `category` varchar(256) NOT NULL,
  `dept_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `clg_admin_activity`
--

CREATE TABLE `clg_admin_activity` (
  `activity_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `activity_type` varchar(50) NOT NULL,
  `activity_body` varchar(256) NOT NULL,
  `other` varchar(256) DEFAULT NULL,
  `clg_admin_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `clg_admin_notify`
--

CREATE TABLE `clg_admin_notify` (
  `notify_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `notify_title` varchar(256) NOT NULL,
  `notify_message` varchar(256) NOT NULL,
  `notify_item` varchar(256) NOT NULL,
  `notify_unit` varchar(256) NOT NULL,
  `notify_quantity` int(11) NOT NULL,
  `notify_from` int(11) NOT NULL,
  `notify_type` int(11) NOT NULL,
  `approve` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `verify` int(11) NOT NULL DEFAULT 0,
  `correct` int(11) NOT NULL DEFAULT 0,
  `clg_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `college`
--

CREATE TABLE `college` (
  `clg_id` int(11) NOT NULL,
  `clg_name` varchar(256) NOT NULL,
  `faculty_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `college_admin`
--

CREATE TABLE `college_admin` (
  `clg_admin_id` int(11) NOT NULL,
  `clg_admin_first_name` varchar(50) NOT NULL,
  `clg_admin_last_name` varchar(50) NOT NULL,
  `clg_admin_email` varchar(256) NOT NULL,
  `clg_admin_password` varchar(256) NOT NULL,
  `clg_admin_mobile` varchar(256) DEFAULT NULL,
  `clg_admin_img_link` varchar(100) DEFAULT NULL,
  `clg_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `otp` varchar(20) DEFAULT NULL,
  `is_expired` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dept_id` int(11) NOT NULL,
  `dept_name` varchar(256) NOT NULL,
  `clg_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `department_admin`
--

CREATE TABLE `department_admin` (
  `dept_admin_id` int(11) NOT NULL,
  `dept_admin_first_name` varchar(50) NOT NULL,
  `dept_admin_last_name` varchar(50) NOT NULL,
  `dept_admin_email` varchar(256) NOT NULL,
  `dept_admin_password` varchar(256) NOT NULL,
  `dept_admin_mobile` varchar(256) DEFAULT NULL,
  `dept_admin_img_link` varchar(100) DEFAULT NULL,
  `dept_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `otp` varchar(20) DEFAULT NULL,
  `is_expired` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dept_admin_activity`
--

CREATE TABLE `dept_admin_activity` (
  `activity_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `activity_type` varchar(256) NOT NULL,
  `activity_body` varchar(256) NOT NULL,
  `dept_admin_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dept_admin_notify`
--

CREATE TABLE `dept_admin_notify` (
  `notify_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `notify_title` varchar(256) NOT NULL,
  `notify_message` varchar(256) NOT NULL,
  `notify_item` varchar(256) NOT NULL,
  `notify_unit` varchar(256) NOT NULL,
  `notify_quantity` int(11) NOT NULL,
  `notify_type` int(11) NOT NULL,
  `notify_from` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `correct` int(11) NOT NULL DEFAULT 0,
  `verify` int(11) NOT NULL DEFAULT 0,
  `approve` int(11) NOT NULL DEFAULT 0,
  `forward` int(11) NOT NULL DEFAULT 0,
  `dept_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `expert_user`
--

CREATE TABLE `expert_user` (
  `eu_id` int(11) NOT NULL,
  `eu_first_name` varchar(50) NOT NULL,
  `eu_last_name` varchar(50) NOT NULL,
  `eu_email` varchar(256) NOT NULL,
  `eu_password` varchar(256) NOT NULL,
  `eu_mobile` varchar(256) DEFAULT NULL,
  `eu_img_link` varchar(100) DEFAULT NULL,
  `dept_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `otp` varchar(20) DEFAULT NULL,
  `is_expired` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `expert_user_activity`
--

CREATE TABLE `expert_user_activity` (
  `activity_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `activity_type` varchar(256) NOT NULL,
  `activity_body` varchar(256) NOT NULL,
  `eu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `expert_user_notify`
--

CREATE TABLE `expert_user_notify` (
  `notify_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `notify_title` varchar(256) NOT NULL,
  `notify_message` varchar(256) NOT NULL,
  `notify_item` varchar(256) NOT NULL,
  `notify_unit` varchar(256) NOT NULL,
  `notify_quantity` int(11) NOT NULL,
  `notify_type` int(11) NOT NULL,
  `notify_from` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `correct` int(11) NOT NULL DEFAULT 0,
  `action` int(11) NOT NULL DEFAULT 0,
  `approve` int(11) DEFAULT 0,
  `dept_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `faculty_id` int(11) NOT NULL,
  `faculty_name` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `file_details`
--

CREATE TABLE `file_details` (
  `file_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `file_name` varchar(256) DEFAULT NULL,
  `file_link` varchar(256) DEFAULT NULL,
  `approved_id` int(11) NOT NULL,
  `remarks` varchar(128) DEFAULT NULL,
  `dept_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `firm`
--

CREATE TABLE `firm` (
  `firm_id` int(11) NOT NULL,
  `firm_name` varchar(256) NOT NULL,
  `owner_name` varchar(256) NOT NULL,
  `firm_email` varchar(256) NOT NULL,
  `firm_mobile` varchar(256) NOT NULL,
  `firm_address` varchar(256) NOT NULL,
  `clg_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(256) NOT NULL,
  `type_id` int(11) NOT NULL,
  `dept_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `non_recurring_stock`
--

CREATE TABLE `non_recurring_stock` (
  `stock_id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `used_for` varchar(256) NOT NULL,
  `particular_name` varchar(256) NOT NULL,
  `particular_type` varchar(256) NOT NULL,
  `previous_stock` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit` varchar(256) NOT NULL,
  `price` float NOT NULL,
  `total_amount` float NOT NULL,
  `issued_quantity` int(11) NOT NULL,
  `balance_stock` int(11) NOT NULL,
  `remarks` varchar(256) NOT NULL,
  `dept_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `non_recurring_stock_levels`
--

CREATE TABLE `non_recurring_stock_levels` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `office_quantity` int(11) NOT NULL,
  `lab_quantity` int(11) NOT NULL,
  `updated` date NOT NULL,
  `dept_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `receiver_non_recurring`
--

CREATE TABLE `receiver_non_recurring` (
  `receiver_id` int(11) NOT NULL,
  `receiver_name` varchar(100) NOT NULL,
  `contact_no` varchar(11) NOT NULL,
  `active_item` int(11) NOT NULL,
  `damage_item` int(11) NOT NULL,
  `repair_item` int(11) NOT NULL,
  `stock_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `receiver_recurring`
--

CREATE TABLE `receiver_recurring` (
  `receiver_id` int(11) NOT NULL,
  `receiver_name` varchar(100) NOT NULL,
  `contact_no` varchar(11) NOT NULL,
  `stock_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `recurring_stock`
--

CREATE TABLE `recurring_stock` (
  `stock_id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `used_for` varchar(256) NOT NULL,
  `particular_name` varchar(256) NOT NULL,
  `particular_type` varchar(256) NOT NULL,
  `previous_stock` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit` varchar(256) NOT NULL,
  `price` float NOT NULL,
  `total_amount` float NOT NULL,
  `issued_quantity` int(11) NOT NULL,
  `balance_stock` int(11) NOT NULL,
  `remarks` varchar(256) NOT NULL,
  `dept_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `recurring_stock_levels`
--

CREATE TABLE `recurring_stock_levels` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `office_quantity` int(11) NOT NULL,
  `lab_quantity` int(11) NOT NULL,
  `updated` date NOT NULL,
  `dept_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `repair_damage`
--

CREATE TABLE `repair_damage` (
  `rd_id` int(11) NOT NULL,
  `dates` date NOT NULL,
  `types` varchar(20) NOT NULL,
  `quantities` int(11) NOT NULL,
  `reason` varchar(256) NOT NULL,
  `receiver_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `super_admin`
--

CREATE TABLE `super_admin` (
  `sup_admin_id` int(11) NOT NULL,
  `sup_admin_first_name` varchar(50) NOT NULL,
  `sup_admin_last_name` varchar(50) NOT NULL,
  `sup_admin_email` varchar(256) NOT NULL,
  `sup_admin_password` varchar(256) NOT NULL,
  `sup_admin_img_link` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `otp` varchar(20) DEFAULT NULL,
  `is_expired` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sup_admin_activity`
--

CREATE TABLE `sup_admin_activity` (
  `activity_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `activity_type` varchar(20) NOT NULL,
  `activity_body` varchar(256) NOT NULL,
  `other` varchar(256) DEFAULT NULL,
  `sup_admin_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sup_admin_notify`
--

CREATE TABLE `sup_admin_notify` (
  `notify_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `notify_title` varchar(256) NOT NULL,
  `notify_message` varchar(256) NOT NULL,
  `notify_from` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `unit_id` int(11) NOT NULL,
  `unit_name` varchar(256) NOT NULL,
  `item_id` int(11) NOT NULL,
  `dept_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category_type`
--
ALTER TABLE `category_type`
  ADD PRIMARY KEY (`type_id`),
  ADD KEY `category_type_ibfk_1` (`dept_id`);

--
-- Indexes for table `clg_admin_activity`
--
ALTER TABLE `clg_admin_activity`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `clg_admin_activity_ibfk_1` (`clg_admin_id`);

--
-- Indexes for table `clg_admin_notify`
--
ALTER TABLE `clg_admin_notify`
  ADD PRIMARY KEY (`notify_id`),
  ADD KEY `clg_admin_notify_ibfk_1` (`clg_id`);

--
-- Indexes for table `college`
--
ALTER TABLE `college`
  ADD PRIMARY KEY (`clg_id`),
  ADD UNIQUE KEY `clg_name` (`clg_name`),
  ADD KEY `college_ibfk_1` (`faculty_id`);

--
-- Indexes for table `college_admin`
--
ALTER TABLE `college_admin`
  ADD PRIMARY KEY (`clg_admin_id`),
  ADD UNIQUE KEY `clg_admin_email` (`clg_admin_email`),
  ADD UNIQUE KEY `clg_id` (`clg_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dept_id`),
  ADD UNIQUE KEY `dept_name` (`dept_name`),
  ADD KEY `department_ibfk_1` (`clg_id`);

--
-- Indexes for table `department_admin`
--
ALTER TABLE `department_admin`
  ADD PRIMARY KEY (`dept_admin_id`),
  ADD UNIQUE KEY `dept_admin_email` (`dept_admin_email`),
  ADD UNIQUE KEY `dept_id` (`dept_id`);

--
-- Indexes for table `dept_admin_activity`
--
ALTER TABLE `dept_admin_activity`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `dept_admin_activity_ibfk_1` (`dept_admin_id`);

--
-- Indexes for table `dept_admin_notify`
--
ALTER TABLE `dept_admin_notify`
  ADD PRIMARY KEY (`notify_id`),
  ADD KEY `dept_admin_notify_ibfk_1` (`dept_id`);

--
-- Indexes for table `expert_user`
--
ALTER TABLE `expert_user`
  ADD PRIMARY KEY (`eu_id`),
  ADD UNIQUE KEY `eu_email` (`eu_email`),
  ADD KEY `expert_user_ibfk_1` (`dept_id`);

--
-- Indexes for table `expert_user_activity`
--
ALTER TABLE `expert_user_activity`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `expert_user_activity_ibfk_1` (`eu_id`);

--
-- Indexes for table `expert_user_notify`
--
ALTER TABLE `expert_user_notify`
  ADD PRIMARY KEY (`notify_id`),
  ADD KEY `expert_user_notify_ibfk_1` (`dept_id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`faculty_id`),
  ADD UNIQUE KEY `faculty_name` (`faculty_name`);

--
-- Indexes for table `file_details`
--
ALTER TABLE `file_details`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `file_details_ibfk_1` (`dept_id`);

--
-- Indexes for table `firm`
--
ALTER TABLE `firm`
  ADD PRIMARY KEY (`firm_id`),
  ADD KEY `firm_ibfk_1` (`clg_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `items_ibfk_1` (`type_id`);

--
-- Indexes for table `non_recurring_stock`
--
ALTER TABLE `non_recurring_stock`
  ADD PRIMARY KEY (`stock_id`),
  ADD KEY `non_recurring_stock_ibfk_1` (`dept_id`);

--
-- Indexes for table `non_recurring_stock_levels`
--
ALTER TABLE `non_recurring_stock_levels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dept_id` (`dept_id`);

--
-- Indexes for table `receiver_non_recurring`
--
ALTER TABLE `receiver_non_recurring`
  ADD PRIMARY KEY (`receiver_id`),
  ADD KEY `stock_id` (`stock_id`);

--
-- Indexes for table `receiver_recurring`
--
ALTER TABLE `receiver_recurring`
  ADD PRIMARY KEY (`receiver_id`),
  ADD KEY `stock_id` (`stock_id`);

--
-- Indexes for table `recurring_stock`
--
ALTER TABLE `recurring_stock`
  ADD PRIMARY KEY (`stock_id`),
  ADD KEY `recurring_stock_ibfk_1` (`dept_id`);

--
-- Indexes for table `recurring_stock_levels`
--
ALTER TABLE `recurring_stock_levels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dept_id` (`dept_id`);

--
-- Indexes for table `repair_damage`
--
ALTER TABLE `repair_damage`
  ADD PRIMARY KEY (`rd_id`),
  ADD KEY `receiver_id` (`receiver_id`);

--
-- Indexes for table `super_admin`
--
ALTER TABLE `super_admin`
  ADD PRIMARY KEY (`sup_admin_id`),
  ADD UNIQUE KEY `sup_admin_email` (`sup_admin_email`);

--
-- Indexes for table `sup_admin_activity`
--
ALTER TABLE `sup_admin_activity`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `sup_admin_activity_ibfk_1` (`sup_admin_id`);

--
-- Indexes for table `sup_admin_notify`
--
ALTER TABLE `sup_admin_notify`
  ADD PRIMARY KEY (`notify_id`),
  ADD KEY `sup_admin_notify_ibfk_1` (`notify_from`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`unit_id`),
  ADD KEY `units_ibfk_1` (`item_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category_type`
--
ALTER TABLE `category_type`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clg_admin_activity`
--
ALTER TABLE `clg_admin_activity`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clg_admin_notify`
--
ALTER TABLE `clg_admin_notify`
  MODIFY `notify_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `college`
--
ALTER TABLE `college`
  MODIFY `clg_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `college_admin`
--
ALTER TABLE `college_admin`
  MODIFY `clg_admin_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `dept_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `department_admin`
--
ALTER TABLE `department_admin`
  MODIFY `dept_admin_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dept_admin_activity`
--
ALTER TABLE `dept_admin_activity`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dept_admin_notify`
--
ALTER TABLE `dept_admin_notify`
  MODIFY `notify_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expert_user`
--
ALTER TABLE `expert_user`
  MODIFY `eu_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expert_user_activity`
--
ALTER TABLE `expert_user_activity`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expert_user_notify`
--
ALTER TABLE `expert_user_notify`
  MODIFY `notify_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `faculty_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `file_details`
--
ALTER TABLE `file_details`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `firm`
--
ALTER TABLE `firm`
  MODIFY `firm_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `non_recurring_stock`
--
ALTER TABLE `non_recurring_stock`
  MODIFY `stock_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `non_recurring_stock_levels`
--
ALTER TABLE `non_recurring_stock_levels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `receiver_non_recurring`
--
ALTER TABLE `receiver_non_recurring`
  MODIFY `receiver_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `receiver_recurring`
--
ALTER TABLE `receiver_recurring`
  MODIFY `receiver_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recurring_stock`
--
ALTER TABLE `recurring_stock`
  MODIFY `stock_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recurring_stock_levels`
--
ALTER TABLE `recurring_stock_levels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `repair_damage`
--
ALTER TABLE `repair_damage`
  MODIFY `rd_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `super_admin`
--
ALTER TABLE `super_admin`
  MODIFY `sup_admin_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sup_admin_activity`
--
ALTER TABLE `sup_admin_activity`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sup_admin_notify`
--
ALTER TABLE `sup_admin_notify`
  MODIFY `notify_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `unit_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `category_type`
--
ALTER TABLE `category_type`
  ADD CONSTRAINT `category_type_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`);

--
-- Constraints for table `clg_admin_activity`
--
ALTER TABLE `clg_admin_activity`
  ADD CONSTRAINT `clg_admin_activity_ibfk_1` FOREIGN KEY (`clg_admin_id`) REFERENCES `college_admin` (`clg_admin_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `clg_admin_notify`
--
ALTER TABLE `clg_admin_notify`
  ADD CONSTRAINT `clg_admin_notify_ibfk_1` FOREIGN KEY (`clg_id`) REFERENCES `college` (`clg_id`);

--
-- Constraints for table `college`
--
ALTER TABLE `college`
  ADD CONSTRAINT `college_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`faculty_id`);

--
-- Constraints for table `college_admin`
--
ALTER TABLE `college_admin`
  ADD CONSTRAINT `college_admin_ibfk_1` FOREIGN KEY (`clg_id`) REFERENCES `college` (`clg_id`);

--
-- Constraints for table `department`
--
ALTER TABLE `department`
  ADD CONSTRAINT `department_ibfk_1` FOREIGN KEY (`clg_id`) REFERENCES `college` (`clg_id`);

--
-- Constraints for table `department_admin`
--
ALTER TABLE `department_admin`
  ADD CONSTRAINT `department_admin_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`);

--
-- Constraints for table `dept_admin_activity`
--
ALTER TABLE `dept_admin_activity`
  ADD CONSTRAINT `dept_admin_activity_ibfk_1` FOREIGN KEY (`dept_admin_id`) REFERENCES `department_admin` (`dept_admin_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `dept_admin_notify`
--
ALTER TABLE `dept_admin_notify`
  ADD CONSTRAINT `dept_admin_notify_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`);

--
-- Constraints for table `expert_user`
--
ALTER TABLE `expert_user`
  ADD CONSTRAINT `expert_user_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`);

--
-- Constraints for table `expert_user_activity`
--
ALTER TABLE `expert_user_activity`
  ADD CONSTRAINT `expert_user_activity_ibfk_1` FOREIGN KEY (`eu_id`) REFERENCES `expert_user` (`eu_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `expert_user_notify`
--
ALTER TABLE `expert_user_notify`
  ADD CONSTRAINT `expert_user_notify_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`);

--
-- Constraints for table `file_details`
--
ALTER TABLE `file_details`
  ADD CONSTRAINT `file_details_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`);

--
-- Constraints for table `firm`
--
ALTER TABLE `firm`
  ADD CONSTRAINT `firm_ibfk_1` FOREIGN KEY (`clg_id`) REFERENCES `college` (`clg_id`);

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `category_type` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `non_recurring_stock`
--
ALTER TABLE `non_recurring_stock`
  ADD CONSTRAINT `non_recurring_stock_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`);

--
-- Constraints for table `non_recurring_stock_levels`
--
ALTER TABLE `non_recurring_stock_levels`
  ADD CONSTRAINT `non_recurring_stock_levels_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`);

--
-- Constraints for table `receiver_non_recurring`
--
ALTER TABLE `receiver_non_recurring`
  ADD CONSTRAINT `receiver_non_recurring_ibfk_1` FOREIGN KEY (`stock_id`) REFERENCES `non_recurring_stock` (`stock_id`);

--
-- Constraints for table `receiver_recurring`
--
ALTER TABLE `receiver_recurring`
  ADD CONSTRAINT `receiver_recurring_ibfk_1` FOREIGN KEY (`stock_id`) REFERENCES `recurring_stock` (`stock_id`);

--
-- Constraints for table `recurring_stock`
--
ALTER TABLE `recurring_stock`
  ADD CONSTRAINT `recurring_stock_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`);

--
-- Constraints for table `recurring_stock_levels`
--
ALTER TABLE `recurring_stock_levels`
  ADD CONSTRAINT `recurring_stock_levels_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`);

--
-- Constraints for table `repair_damage`
--
ALTER TABLE `repair_damage`
  ADD CONSTRAINT `repair_damage_ibfk_1` FOREIGN KEY (`receiver_id`) REFERENCES `receiver_non_recurring` (`receiver_id`);

--
-- Constraints for table `sup_admin_activity`
--
ALTER TABLE `sup_admin_activity`
  ADD CONSTRAINT `sup_admin_activity_ibfk_1` FOREIGN KEY (`sup_admin_id`) REFERENCES `super_admin` (`sup_admin_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sup_admin_notify`
--
ALTER TABLE `sup_admin_notify`
  ADD CONSTRAINT `sup_admin_notify_ibfk_1` FOREIGN KEY (`notify_from`) REFERENCES `college` (`clg_id`);

--
-- Constraints for table `units`
--
ALTER TABLE `units`
  ADD CONSTRAINT `units_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
